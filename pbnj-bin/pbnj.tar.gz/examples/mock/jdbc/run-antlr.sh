java -cp ../../../jar/antlr-3.1.3.jar org.antlr.Tool $1

