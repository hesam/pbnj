package com.tftpsuite.server;

public class TFTPServer {

   /**
    * @param args
    */
   public static void main(String[] args) {
      // TODO Auto-generated method stub

   }

}
