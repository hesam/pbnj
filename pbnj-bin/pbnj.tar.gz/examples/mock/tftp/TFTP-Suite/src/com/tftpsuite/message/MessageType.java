package com.tftpsuite.message;

public enum MessageType {
   RRQ,
   WRQ,
   DATA,
   ACK,
   ERROR,
   TIMEOUT
}
