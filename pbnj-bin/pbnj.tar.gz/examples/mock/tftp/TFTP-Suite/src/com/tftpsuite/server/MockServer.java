package com.tftpsuite.server;

import com.tftpsuite.message.Message;

public class MockServer { //mocked

   public MockServer() {}
   
   public Message serverSendMessage() { return null; }

   public void serverReceiveMessage(Message message) {}
}
