package com.tftpsuite.client;

public enum Action {
   READ,
   WRITE
}
