package com.tftpsuite.message;

public class TIMEOUTMessage extends Message {

   public TIMEOUTMessage() {
      super(MessageType.TIMEOUT, -1, -1);
   }

}
